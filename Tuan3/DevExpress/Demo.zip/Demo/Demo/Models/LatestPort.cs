﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.Models
{
    public class LatestPort
    {
        public string Port { get; set; }
        public string Flag { get; set; }
        public string Arrival { get; set; }
        public string Departure { get; set; }
        public string Duration { get; set; }
    }
}
